package priyanka.sdet.selenium.java.priyankaAssignment1;

import java.io.FileInputStream;
import java.util.List;
import java.util.Properties;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import priyanka.sdet.selenium.java.priyankaAssignmentMain.BaseClass;

public class Selectmenu extends BaseClass{
	
	
	static WebDriver driver;
	 static Properties pro;
	 static FileInputStream fs; 
	
	
	
		public static void Initalizedriver(String browser) throws Exception  
		{ 
			
		driver=Getdriver(browser);
	    pro=new Properties(); 
	    fs=new FileInputStream( "C:\\Users\\PR376472\\eclipse-workspace\\priyanka-sdet-selenium\\src\\PriyankaAssignment1.properties"); 
	     pro.load(fs);
		  }
	 
	 
	  public static void Closedriver() {
		  
		  driver.quit();
	  
	 }
 
  
	 
	public static void Tc1_05_001_selectmenu() 
		 {
		 driver.get(pro.getProperty("selecturl"));
		 driver.manage().window().maximize();
			WebElement carsDropdown = driver.findElement(By.id("speed-button"));
			carsDropdown.click();
			List<WebElement> allValues = driver.findElements(By.xpath(pro.getProperty("speedmenu")));

			for (WebElement ele : allValues) {
				System.out.println(ele.getText());
				ele.click();
				carsDropdown.click();
				JavascriptExecutor jse = (JavascriptExecutor) driver;
				jse.executeScript("window.scrollBy(0,250)", "");
			}
			carsDropdown.click();
		 }
	
	
	 public static void Tc1_05_002_selectmenu() 
	 {
	 driver.get(pro.getProperty("selecturl"));
	 driver.manage().window().maximize();
		WebElement carsDropdown = driver.findElement(By.id("files-button"));
		carsDropdown.click();
		List<WebElement> allValues = driver.findElements(By.xpath(pro.getProperty("filesmenu")));

		for (WebElement ele : allValues) {
			System.out.println(ele.getText());
			ele.click();
			carsDropdown.click();
			JavascriptExecutor jse = (JavascriptExecutor) driver;
			jse.executeScript("window.scrollBy(0,250)", "");
		}
		carsDropdown.click();
	 }
	 
	 public static void Tc1_05_003_selectmenu() 
	 {
	 driver.get(pro.getProperty("selecturl"));
	 driver.manage().window().maximize();
		WebElement carsDropdown = driver.findElement(By.id("number-button"));
		carsDropdown.click();
		List<WebElement> allValues = driver.findElements(By.xpath(pro.getProperty("numbermenu")));

		for (WebElement ele : allValues) {
			System.out.println(ele.getText());
			ele.click();
			carsDropdown.click();
			JavascriptExecutor jse = (JavascriptExecutor) driver;
			jse.executeScript("window.scrollBy(0,250)", "");
		}
		carsDropdown.click();
	 }
	 
	 
	 public static void Tc1_05_004_selectmenu() 
	 {
	 driver.get(pro.getProperty("selecturl"));
	 driver.manage().window().maximize();
		WebElement carsDropdown = driver.findElement(By.id("salutation-button"));
		carsDropdown.click();
		List<WebElement> allValues = driver.findElements(By.xpath(pro.getProperty("salutationmenu")));

		for (WebElement ele : allValues) {
			System.out.println(ele.getText());
			ele.click();
			carsDropdown.click();
			JavascriptExecutor jse = (JavascriptExecutor) driver;
			jse.executeScript("window.scrollBy(0,250)", "");
		}
		carsDropdown.click();
	 }}
		
		
		
	