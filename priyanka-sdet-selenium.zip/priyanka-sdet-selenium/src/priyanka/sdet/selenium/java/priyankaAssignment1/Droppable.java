package priyanka.sdet.selenium.java.priyankaAssignment1;

import java.io.FileInputStream;
import java.util.Properties;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

import priyanka.sdet.selenium.java.priyankaAssignmentMain.BaseClass;


	public class Droppable extends BaseClass {
		static WebDriver driver;
		 static Properties pro;
		 static FileInputStream fs; 
		
		
		
			public static void Initalizedriver(String browser) throws Exception  
			{ 
				
			driver=Getdriver(browser);
		    pro=new Properties(); 
		    fs=new FileInputStream( "C:\\Users\\PR376472\\eclipse-workspace\\priyanka-sdet-selenium\\src\\PriyankaAssignment1.properties"); 
		     pro.load(fs);
			  }
		 
		 
		  public static void Closedriver() {
			  
			  driver.quit();
		  
		 }
	  
		
		public static void Tc1_03_001_droppable() {
			 driver.get(pro.getProperty("dragurl")); 
		       WebElement src = driver.findElement(By.xpath(pro.getProperty("source")));
				WebElement dest = driver.findElement(By.xpath(pro.getProperty("destination")));
				Actions act = new Actions(driver);
				act.dragAndDrop(src, dest).build().perform();
			WebElement w=driver.findElement(By.xpath("//div[@id='droppable']"));
			if(w.getText().equalsIgnoreCase("dropped!"))
			{
				System.out.println("box is dropped");
			}
				
			}
		 
		
		 public static void Tc1_03_002_droppable() {
			 driver.get(pro.getProperty("dragurl")); 
		       WebElement src = driver.findElement(By.xpath(pro.getProperty("source")));
				WebElement dest = driver.findElement(By.xpath(pro.getProperty("newdest")));
				Actions act = new Actions(driver);
				act.dragAndDrop(src, dest).build().perform();
				WebElement w=driver.findElement(By.xpath("//div[@id='droppable']"));
				if(!w.getText().equalsIgnoreCase("dropped!"))
				{
					System.out.println("box is not dropped");
				}
				
			}

		}
	  
	  
	

