package priyanka.sdet.selenium.java.priyankaAssignment1;
import java.io.FileInputStream;
import java.util.List;
import java.util.Properties;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import priyanka.sdet.selenium.java.priyankaAssignmentMain.BaseClass;

public class Carrentalblock extends BaseClass  {
	static WebDriver driver;
	 static Properties pro;
	 static FileInputStream fs; 
	
	
	
		public static void Initalizedriver(String browser) throws Exception  
		{ 
			
		driver=Getdriver(browser);
	    pro=new Properties(); 
	    fs=new FileInputStream( "C:\\Users\\PR376472\\eclipse-workspace\\priyanka-sdet-selenium\\src\\PriyankaAssignment1.properties"); 
	     pro.load(fs);
		  }
	 
	 
	  public static void Closedriver() {
		  
		  driver.quit();
	  
	 }
	 static String s6 = "SUV";
	static String txt1 = "";
	

	public static void Tc1_06_001_carrentalblock() 
	 {
		 driver.get(pro.getProperty("rentcarurl"));
		 driver.manage().window().maximize();
			driver.findElement(By.id("car-type-button")).click();
			List<WebElement> str1 = driver.findElements(By.xpath(pro.getProperty("cartypemenu1")));

			for (int i = 0; i < str1.size(); i++) {

				txt1 = str1.get(i).getText();
				if (txt1.equalsIgnoreCase(s6)) {
					str1.get(i).click();
					break;
				}
			}
			driver.findElement(By.xpath(pro.getProperty("transmisson1"))).click();
			driver.findElement(By.xpath(pro.getProperty("insurance1"))).click();
			driver.findElement(By.xpath(pro.getProperty("spinner1"))).sendKeys("2");
			driver.findElement(By.xpath(pro.getProperty("button1"))).click();
			
	 }
			
					  
			static String s7 = "Luxury";
			static String txt2 = "";
			
			
			public static void Tc1_06_002_carrentalblock() 
			 {
				 driver.get(pro.getProperty("rentcarurl"));
				 driver.manage().window().maximize();
					driver.findElement(By.id("ui-id-8-button")).click();
					List<WebElement> str1 = driver.findElements(By.xpath(pro.getProperty("cartypemenu2")));

					for (int i = 0; i < str1.size(); i++) {

						txt2= str1.get(i).getText();
						if (txt2.equalsIgnoreCase(s7)) {
							str1.get(i).click();
							break;
						}
					}
					driver.findElement(By.xpath(pro.getProperty("transmisson2"))).click();
					driver.findElement(By.xpath(pro.getProperty("insurance2"))).click();
					driver.findElement(By.xpath(pro.getProperty("spinner2"))).sendKeys("1");
					driver.findElement(By.xpath(pro.getProperty("button2"))).click();
					
			 }}