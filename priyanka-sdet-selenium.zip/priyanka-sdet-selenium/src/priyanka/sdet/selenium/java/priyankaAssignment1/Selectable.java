package priyanka.sdet.selenium.java.priyankaAssignment1;

import java.io.FileInputStream;
import java.util.List;
import java.util.Properties;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import priyanka.sdet.selenium.java.priyankaAssignmentMain.BaseClass;


public class Selectable extends BaseClass{
	static WebDriver driver;
	 static Properties pro;
	 static FileInputStream fs; 
	
	
	
		public static void Initalizedriver(String browser) throws Exception  
		{ 
			
		driver=Getdriver(browser);
	    pro=new Properties(); 
	    fs=new FileInputStream( "C:\\Users\\PR376472\\eclipse-workspace\\priyanka-sdet-selenium\\src\\PriyankaAssignment1.properties");; 
	     pro.load(fs);
		  }
	 
	 
	  public static void Closedriver() {
		  
		  driver.quit();
	  
	 }
 
	 
  
	 
	public static void Tc1_01_001_selectable() {
		driver.get(pro.getProperty("url")); 
		List<WebElement> wb = driver.findElements(By.xpath(pro.getProperty("clickurl")));

		for (int i = 0; i < wb.size(); i++) {
			wb.get(i).click();
			String txt = wb.get(i).getText();
			System.out.println(txt);
		}
	}
  
  
}
