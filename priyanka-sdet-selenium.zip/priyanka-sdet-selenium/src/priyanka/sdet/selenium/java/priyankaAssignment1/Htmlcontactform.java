package priyanka.sdet.selenium.java.priyankaAssignment1;

import java.io.FileInputStream;
import java.util.Properties;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;

import priyanka.sdet.selenium.java.priyankaAssignmentMain.BaseClass;

public class Htmlcontactform extends BaseClass{
	static WebDriver driver;
	 static Properties pro;
	 static FileInputStream fs; 
	
	
	
		public static void Initalizedriver(String browser) throws Exception  
		{ 
			
		driver=Getdriver(browser);
	    pro=new Properties(); 
	    fs=new FileInputStream( "C:\\Users\\PR376472\\eclipse-workspace\\priyanka-sdet-selenium\\src\\PriyankaAssignment1.properties"); 
	     pro.load(fs);
		  }
	 
	 
	  public static void Closedriver() {
		  
		  driver.quit();
	  
	 }
  
  public static void Tc1_02_001_htmlcontactform() {
		driver.get(pro.getProperty("formurl")); 
		driver.findElement(By.xpath(pro.getProperty("firstname"))).sendKeys("Priyanka");
		driver.findElement(By.xpath(pro.getProperty("lastname"))).sendKeys("s");
		driver.findElement(By.xpath(pro.getProperty("country"))).sendKeys("India");
		driver.findElement(By.xpath(pro.getProperty("description"))).sendKeys("No comments");
		driver.findElement(By.partialLinkText(pro.getProperty("firstlink"))).sendKeys(Keys.chord(Keys.CONTROL, Keys.RETURN));
		driver.findElement(By.partialLinkText(pro.getProperty("secondlink"))).sendKeys(Keys.chord(Keys.CONTROL, Keys.RETURN));
		driver.findElement(By.xpath(pro.getProperty("formbutton"))).submit();
	}
  }
  
  

