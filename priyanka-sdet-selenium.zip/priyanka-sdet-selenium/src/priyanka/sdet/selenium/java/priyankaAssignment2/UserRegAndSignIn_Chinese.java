package priyanka.sdet.selenium.java.priyankaAssignment2;

import java.io.FileInputStream;
import java.util.Properties;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import priyanka.sdet.selenium.java.priyankaAssignmentMain.BaseClass;

public class UserRegAndSignIn_Chinese extends BaseClass{

	static WebDriver driver;
	 static Properties pro;
	 static FileInputStream fs; 
	static int a;
	
	
		public static void Initalizedriver(String browser) throws Exception  
		{ 
			
		driver=Getdriver(browser);
	    pro=new Properties(); 
	    fs=new FileInputStream( "C:\\Users\\PR376472\\eclipse-workspace\\priyanka-sdet-selenium\\src\\PriyankaAssignment2.properties"); 
	     pro.load(fs);
		  }
	 
	 
	  public static void Closedriver() {
		  
		  driver.quit();
	  
	 }

		public static void Tc2_02_001_RegistrationSignInCN() throws Exception {
			driver.get(pro.getProperty("urlcn"));
			a=Random();
			driver.manage().window().maximize();
			Thread.sleep(5000);
			driver.findElement(By.xpath(pro.getProperty("registercn"))).click();
			Thread.sleep(5000);
			driver.findElement(By.xpath(pro.getProperty("lastnamecn"))).sendKeys("s");
			driver.findElement(By.id(pro.getProperty("firstnamecn"))).sendKeys("priyanka");
		    driver.findElement(By.id(pro.getProperty("emailcn"))).sendKeys("priya"+a+"@gmail.com");
		    driver.findElement(By.id(pro.getProperty("phonenumcn"))).sendKeys("+852349"+a+"99");
			driver.findElement(By.id(pro.getProperty("passwordpasscn"))).sendKeys("priya@123");
			driver.findElement(By.id(pro.getProperty("confirmpasswordcn"))).sendKeys("priya@123");
			 driver.findElement(By.id(pro.getProperty("addresscn"))).sendKeys("Blue valley");
			Select s1 = new Select(driver.findElement(By.id(pro.getProperty("birthmonthcn"))));
			s1.selectByValue("03");
			Select s2 = new Select(driver.findElement(By.id(pro.getProperty("birthyearcn"))));
			s2.selectByVisibleText("1995");
			driver.findElement(By.id(pro.getProperty("checkboxcn"))).click();
			driver.findElement(By.id(pro.getProperty("submitcn"))).click();
			Thread.sleep(3000);
			driver.findElement(By.id(pro.getProperty("usernamecn"))).sendKeys("priya"+a+"@gmail.com");
			driver.findElement(By.id(pro.getProperty("passwordcn"))).sendKeys("priya@123");
			driver.findElement(By.xpath(pro.getProperty("signinbtncn"))).click();
			Thread.sleep(5000);
			driver.findElement(By.id(pro.getProperty("signoutbtncn"))).click();
			driver.findElement(By.id(pro.getProperty("confirmbtncn"))).click();
			
		}

		static String st ="您輸入的電郵或密碼不正確。請再試一次，或點擊下方連結新建一個帳戶";

		
		
		public static void Tc2_02_002_InvalidPasswordValidationCN() throws Exception {
			driver.get(pro.getProperty("urlcn"));
			driver.manage().window().maximize();
			Thread.sleep(10000);
			driver.findElement(By.cssSelector(pro.getProperty("clicksignincn"))).click();
			driver.findElement(By.id(pro.getProperty("usernamecn"))).sendKeys("privasan@gmail.com");
			driver.findElement(By.id(pro.getProperty("passwordcn"))).sendKeys("priya@345");
			driver.findElement(By.xpath(pro.getProperty("signinbtncn"))).click();
			Thread.sleep(3000);
			WebElement w = driver.findElement(By.id(pro.getProperty("messagecn")));
			if (w.getText().equalsIgnoreCase(st)) {
				System.out.println("Invalid password message is validated");
			}
			Thread.sleep(5000);
			
		}
		
		static String s="我們已發出一封電子郵件到你的電郵信箱，請點擊郵件內的連結以重設密碼";

		
		public static void Tc2_02_003_ForgotPasswordValidationCN() throws Exception {
			driver.get(pro.getProperty("urlcn"));
			driver.manage().window().maximize();
			Thread.sleep(10000);
			driver.findElement(By.cssSelector(pro.getProperty("clicksignincn"))).click();
			Thread.sleep(5000);
			driver.findElement(By.id(pro.getProperty("forgotpassclickcn"))).click();
			Thread.sleep(5000);
			driver.findElement(By.id(pro.getProperty("usernamecn"))).sendKeys("priya5@gmail.com");
			driver.findElement(By.xpath(pro.getProperty("nextbuttoncn"))).click();
			Thread.sleep(5000);
			WebElement wb = driver.findElement(By.id(pro.getProperty("aftersubmitcn")));
			if(wb.getText().equalsIgnoreCase(s))
			{
				System.out.println("Forgot password is validated");
			}
			Thread.sleep(5000);
		}


}
