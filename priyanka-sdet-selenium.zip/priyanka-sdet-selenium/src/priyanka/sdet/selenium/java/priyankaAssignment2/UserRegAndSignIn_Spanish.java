package priyanka.sdet.selenium.java.priyankaAssignment2;




import java.io.FileInputStream;
import java.util.List;
import java.util.Properties;

import org.json.simple.JSONObject;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import priyanka.sdet.selenium.java.priyankaAssignmentMain.BaseClass;


public class UserRegAndSignIn_Spanish extends BaseClass{
	
	static WebDriver driver;
	 static Properties pro;
	 static FileInputStream fs;
	 static JSONObject user;
	static int a;
	
	
		public static void Initalizedriver(String browser) throws Exception  
		{ 
			
		driver=Getdriver(browser);
	    pro=new Properties(); 
	    fs=new FileInputStream( "C:\\Users\\PR376472\\eclipse-workspace\\priyanka-sdet-selenium\\src\\PriyankaAssignment2.properties"); 
	     pro.load(fs);
		  }
	 
	 
	  public static void Closedriver() {
		  
		  driver.quit();
	  
	 }
	  
	  public static void Tc2_04_001_RegistrationSignInES() throws Exception
	  {
	  driver.get(pro.getProperty("urles")); 
	  driver.manage().window().maximize();
	  driver.manage().deleteAllCookies();
	  user=readWriteJSON();
	  a=Random();
	  Thread.sleep(5000);
	  driver.findElement(By.xpath(pro.getProperty("acceptcookieses"))).click();
	  JavascriptExecutor jse = (JavascriptExecutor)driver;
	   jse.executeScript("window.scrollBy(0,750)", "");
	  driver.findElement(By.linkText(pro.getProperty("registeres"))).click();
	  Thread.sleep(3000);
	  driver.findElement(By.id(pro.getProperty("genderes"))).click();
	  driver.findElement(By.id(pro.getProperty("firstnamees"))).sendKeys(user.get("firstName").toString());
	  driver.findElement(By.id(pro.getProperty("lastnamees"))).sendKeys(user.get("lastName").toString());
	  driver.findElement(By.id(pro.getProperty("emailes"))).sendKeys((user.get("emailId").toString())+a+"@gmail.com") ; 
	  driver.findElement(By.id(pro.getProperty("passwordpasses"))).sendKeys(user.get("password").toString());
	  driver.findElement(By.id(pro.getProperty("confirmpasswordes"))).sendKeys(user.get("confirmPass").toString()); 
	  Select s=new Select(driver.findElement(By.id(pro.getProperty("birthdayes"))));
	  s.selectByVisibleText("16"); 
	  Select s1=new Select(driver.findElement(By.id(pro.getProperty("birthmonthes"))));
	  s1.selectByVisibleText("3");
	  Select s2=new Select(driver.findElement(By.id(pro.getProperty("birthyeares"))));
	  s2.selectByVisibleText("1995");
	  driver.findElement(By.id(pro.getProperty("phonenumes"))).sendKeys(user.get("phoneNum").toString());
	  driver.findElement(By.id(pro.getProperty("submitde"))).click();
	  Thread.sleep(3000);
	  driver.findElement(By.id(pro.getProperty("usernamees"))).sendKeys((user.get("emailId").toString())+a+"@gmail.com");
	  driver.findElement(By.id(pro.getProperty("passwordes"))).sendKeys(user.get("password").toString());
	  driver.findElement(By.id(pro.getProperty("signinbtnes"))).click();
	  Thread.sleep(5000);
	  driver.findElement(By.id(pro.getProperty("signoutbtnes"))).click();
	  driver.findElement(By.id(pro.getProperty("confirmbtnes"))).click();
	  }
	  
	  static String  st="La combinaci�n de correo electr�nico y la contrase�a que has introducido es incorrecta. Por favor, int�ntalo de nuevo, o haz clic en el siguiente enlace para crear una cuenta.";
	  
	  
	   
	  public static void Tc2_04_002_InvalidPasswordValidationES() throws Exception {
	  driver.get(pro.getProperty("urles")); driver.manage().window().maximize();
	  Thread.sleep(5000); 
	  //driver.findElement(By.xpath(pro.getProperty("acceptcookieses"))).click();
	  driver.findElement(By.linkText(pro.getProperty("clicksignines"))). click();
	  driver.findElement(By.id(pro.getProperty("usernamees"))).sendKeys(user.get("emailId").toString());
	  driver.findElement(By.id(pro.getProperty("passwordes"))).sendKeys(user.get("wrongPass").toString());
	  driver.findElement(By.id(pro.getProperty("signinbtnes"))).click();
	  Thread.sleep(3000); WebElement
	  w=driver.findElement(By.id(pro.getProperty("messagees")));
	  if(w.getText().equalsIgnoreCase(st)) {
	  System.out.println("Invalid password message is validated"); }
	  
	  
	  }
	  
	  
	   public static void Tc2_04_003_ForgotPasswordValidationES() throws Exception { driver.get(pro.getProperty("urles"));
	  driver.manage().window().maximize(); 
	  Thread.sleep(5000); 
	  //driver.findElement(By.xpath(pro.getProperty("acceptcookieses"))).click();
	  driver.findElement(By.linkText(pro.getProperty("clicksignines"))). click();
	  driver.findElement(By.id(pro.getProperty("forgotpassclickes"))).click();
	 List<WebElement> li= driver.findElements(By.id(pro.getProperty("usernamees")));
	 for(int i=0;i<li.size();i++)
	 {
		 li.get(i).sendKeys("privasan95@gmail.com");
	 }
	  driver.findElement(By.id(pro.getProperty("nextbuttones"))).click(); 
	  driver.findElement(By.id(pro.getProperty("aftersubmites"))).click();
	  Thread.sleep(3000);
	  WebElement wb= driver.findElement(By.cssSelector(pro.getProperty("successmessagees")));
	  System.out.println(wb.getText());
	  }
	 
}
