package priyanka.sdet.selenium.java.priyankaAssignment3;

import java.io.FileInputStream;

import java.util.List;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;


import priyanka.sdet.selenium.java.priyankaAssignmentMain.BaseClass;




public class MakeMyTripBooking extends BaseClass{
	static WebDriver driver;
	 static Properties pro;
	 static FileInputStream fs; 
	
	
	
		public static void Initalizedriver(String browser) throws Exception  
		{ 
			
		driver=Getdriver(browser);
	    pro=new Properties(); 
	    fs=new FileInputStream( "C:\\Users\\PR376472\\eclipse-workspace\\priyanka-sdet-selenium\\src\\PriyankaAssignment3.properties"); 
	     pro.load(fs);
		  }
	 
	 
	  public static void Closedriver() {
		  
		  driver.quit();
	  
	 }
	 
	  
	 
	 public static void Tc3_01_001_MakeMyTripBooking() throws Exception{
		 
		 driver.manage().timeouts().implicitlyWait(20000, TimeUnit.SECONDS);
			
		driver.manage().window().maximize();
		driver.manage().deleteAllCookies();
		Thread.sleep(5000);
		driver.get(pro.getProperty("url3"));
		WebElement w=driver.findElement(By.xpath(pro.getProperty("twoway")));
		w.click();
		driver.findElement(By.xpath(pro.getProperty("src"))).click();
	    driver.findElement(By.id(pro.getProperty("srccity"))).click();
		driver.findElement(By.id(pro.getProperty("destcity"))).click();
	    date(pro.getProperty("srcdate"),"29");
	    date(pro.getProperty("destdate"),"30");
	    driver.findElement(By.xpath(pro.getProperty("search"))).click();
	    Thread.sleep(100000);
	    driver.findElement(By.xpath(pro.getProperty("book"))).click();
	    Thread.sleep(10000);
	    driver.findElement(By.cssSelector(pro.getProperty("continue"))).click();
	    //String w1=driver.getWindowHandle();
	    driver.navigate().to(pro.getProperty("newurl"));
	    List<WebElement> l=driver.findElements(By.cssSelector(pro.getProperty("getdetails")));
	    for(int i=0;i<l.size();i++)
	    {
	    	System.out.println(l.get(i).getText());
	    	System.out.println("-----------------------");
	    }
	 }
	public static void date(String s,String s1)
	{
		List<WebElement> li=driver.findElements(By.xpath(s));
		for(int i=0;i<li.size();i++)
		{
			if(li.get(i).getText().equalsIgnoreCase(s1))
			{
				System.out.println(li.get(i).getText());
				li.get(i).click();
				break;
			}
		}
	}}
	
