package priyanka.sdet.selenium.java.priyankaAssignmentMain;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileReader;
import java.util.Random;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
public class BaseClass {
	
	static WebDriver driver;
	static int a;
	static JSONObject user;
	 static File file;
	 static FileInputStream fis;
	 static XSSFWorkbook workbook;
	 static XSSFSheet sh;
	
	public static WebDriver Getdriver(String browser) throws Exception {
		
	   
		if(browser.equalsIgnoreCase("Chrome"))
	  {
		  
		  System.setProperty("webdriver.chrome.driver",
		  "C:\\Users\\PR376472\\eclipse-workspace\\priyanka-sdet-selenium\\src\\drivers\\chromedriver.exe");
		  driver= new ChromeDriver(); 
		  }
	  else if(browser.equalsIgnoreCase("Firefox"))
	  {
		  
		  System.setProperty("webdriver.gecko.driver","C:\\Users\\PR376472\\eclipse-workspace\\priyanka-sdet-selenium\\src\\drivers\\geckodriver.exe");
		    
			driver= new FirefoxDriver(); 
		  }
		return driver;
		
		
}
	public static JSONObject readWriteJSON() throws Exception {
		  JSONParser jsonParser = new JSONParser();
		  try  {
		  FileReader reader = new FileReader("C:\\Users\\PR376472\\eclipse-workspace\\priyanka-sdet-selenium\\src\\PriyankaAssignment2Datasheet_Spanish.json");
		  //Read JSON file
		              Object obj = jsonParser.parse(reader);
		              JSONArray usersList = (JSONArray) obj;
			   JSONObject users = (JSONObject) usersList.get(0);
			    user = (JSONObject) users.get("users");
			   
			  System.out.println(user); //This prints each data in the block
			  
			  
			 }
		               catch (Exception e)
		              {
		  e.printStackTrace();
		  }
		  return user;
		  }
	
	public static XSSFSheet Readexcel() throws Exception
     {
 	 
      file= new File("C:\\Users\\PR376472\\eclipse-workspace\\priyanka-sdet-selenium\\src\\priyankaAssignment2Datasheet_Germany.xlsx");
 	 fis= new FileInputStream(file);
 	  workbook = new XSSFWorkbook (fis);
 	    XSSFSheet sh=workbook.getSheet("assignment2-DE");
 	   return sh;
		 }
      
    
	public static int Random()
	  {
		  Random r=new Random();
		   a=r.nextInt(1000);
		   return a;
	  }

}
