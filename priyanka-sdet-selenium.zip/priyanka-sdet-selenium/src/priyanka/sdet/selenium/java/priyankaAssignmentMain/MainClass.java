package priyanka.sdet.selenium.java.priyankaAssignmentMain;

import priyanka.sdet.selenium.java.priyankaAssignment1.Carrentalblock;

import priyanka.sdet.selenium.java.priyankaAssignment1.Datepicker;
import priyanka.sdet.selenium.java.priyankaAssignment1.Droppable;
import priyanka.sdet.selenium.java.priyankaAssignment1.Htmlcontactform;
import priyanka.sdet.selenium.java.priyankaAssignment1.Selectable;
import priyanka.sdet.selenium.java.priyankaAssignment1.Selectmenu;
import priyanka.sdet.selenium.java.priyankaAssignment2.UserRegAndSignIn_Chinese;
import priyanka.sdet.selenium.java.priyankaAssignment2.UserRegAndSignIn_Germany;
import priyanka.sdet.selenium.java.priyankaAssignment2.UserRegAndSignIn_Spanish;
import priyanka.sdet.selenium.java.priyankaAssignment2.UserRegAndSignIn_UKEnglish;
import priyanka.sdet.selenium.java.priyankaAssignment3.MakeMyTripBooking;

public class MainClass {

	public static void main(String[] args) throws Exception {

		
		  Selectable.Initalizedriver("chrome"); Selectable.Tc1_01_001_selectable();
		  Selectable.Closedriver();
		  System.out.println("Tc1_01_001_selectable()-passed");
		  Htmlcontactform.Initalizedriver("chrome");
		  Htmlcontactform.Tc1_02_001_htmlcontactform(); Htmlcontactform.Closedriver();
		  System.out.println("Tc1_02_001_htmlcontactform()-passed");
		  Droppable.Initalizedriver("chrome"); Droppable.Tc1_03_001_droppable();
		  Droppable.Tc1_03_002_droppable(); Droppable.Closedriver();
		  System.out.println("Tc1_03_001_droppable()-passed");
		  System.out.println("Tc1_03_002_droppable()-passed");
		  Datepicker.Initalizedriver("chrome"); Datepicker.Tc1_04_001_datepicker();
		  Datepicker.Closedriver();
		  System.out.println("Tc1_04_001_datepicker()-passed");
		  Selectmenu.Initalizedriver("chrome"); Selectmenu.Tc1_05_001_selectmenu();
		  Selectmenu.Tc1_05_002_selectmenu(); Selectmenu.Tc1_05_003_selectmenu();
		  Selectmenu.Tc1_05_004_selectmenu(); Selectmenu.Closedriver();
		  System.out.println("Tc1_05_001_selectmenu()-passed");
		  System.out.println("Tc1_05_002_selectmenu()-passed");
		  System.out.println("Tc1_05_003_selectmenu()-passed");
		  System.out.println("Tc1_05_004_selectmenu()-passed");
		  Carrentalblock.Initalizedriver("chrome");
		  Carrentalblock.Tc1_06_001_carrentalblock();
		  Carrentalblock.Tc1_06_002_carrentalblock(); Carrentalblock.Closedriver();
		  System.out.println("Tc1_06_001_carrentalblock()-passed");
		  System.out.println("Tc1_06_002_carrentalblock()-passed");
		  UserRegAndSignIn_UKEnglish.Initalizedriver("chrome");
		  UserRegAndSignIn_UKEnglish.Tc2_01_001_RegistrationSignInUK();
		  UserRegAndSignIn_UKEnglish.Tc2_01_002_InvalidPasswordValidationUK();
		  UserRegAndSignIn_UKEnglish.Tc2_01_003_ForgotPasswordValidationUK();
		  UserRegAndSignIn_UKEnglish.Closedriver();
		  System.out.println("Tc2_01_001_RegistrationSignInUK()-passed");
		  System.out.println("Tc2_01_002_InvalidPasswordValidationUK()-passed");
		  System.out.println("Tc2_01_003_ForgotPasswordValidationUK()-passed");
		  
		  
		  UserRegAndSignIn_Chinese.Initalizedriver("chrome");
		  UserRegAndSignIn_Chinese.Tc2_02_001_RegistrationSignInCN();
		  UserRegAndSignIn_Chinese.Tc2_02_002_InvalidPasswordValidationCN();
		  UserRegAndSignIn_Chinese.Tc2_02_003_ForgotPasswordValidationCN();
		  UserRegAndSignIn_Chinese.Closedriver();
		  System.out.println("Tc2_02_001_RegistrationSignInCN()-passed");
		  System.out.println("Tc2_02_002_InvalidPasswordValidationCN()-passed");
		  System.out.println("Tc2_02_003_ForgotPasswordValidationCN()-passed");
		  
		  
		  UserRegAndSignIn_Germany.Initalizedriver("chrome");
		  UserRegAndSignIn_Germany.Tc2_03_001_RegistrationSignInDE();
		  UserRegAndSignIn_Germany.Tc2_03_002_InvalidPasswordValidationDE();
		  UserRegAndSignIn_Germany.Tc2_03_003_ForgotPasswordValidationDE();
		  UserRegAndSignIn_Germany.Closedriver();
		  System.out.println("Tc2_03_001_RegistrationSignInDE()-passed");
		  System.out.println("Tc2_03_002_InvalidPasswordValidationDE()-passed");
		  System.out.println("Tc2_03_003_ForgotPasswordValidationDE()-passed");
		  
		  
		  UserRegAndSignIn_Spanish.Initalizedriver("chrome");
		  UserRegAndSignIn_Spanish.Tc2_04_001_RegistrationSignInES();
		  UserRegAndSignIn_Spanish.Tc2_04_002_InvalidPasswordValidationES();
		  UserRegAndSignIn_Spanish.Tc2_04_003_ForgotPasswordValidationES();
		  UserRegAndSignIn_Spanish.Closedriver();
		  
		  System.out.println("Tc2_04_001_RegistrationSignInES()-passed");
		  System.out.println("Tc2_04_002_InvalidPasswordValidationES()-passed");
		  System.out.println("Tc2_04_003_ForgotPasswordValidationES()-passed");
		  MakeMyTripBooking.Initalizedriver("chrome");
		  MakeMyTripBooking.Tc3_01_001_MakeMyTripBooking();
		  MakeMyTripBooking.Closedriver();
		  System.out.println("Tc3_01_001_MakeMyTripBooking()-passed");
		  
		  
		  
		  Selectable.Initalizedriver("firefox"); Selectable.Tc1_01_001_selectable();
		  Selectable.Closedriver();
		  System.out.println("Tc1_01_001_selectable()-passed");
		  Htmlcontactform.Initalizedriver("firefox");
		  Htmlcontactform.Tc1_02_001_htmlcontactform(); Htmlcontactform.Closedriver();
		  System.out.println("Tc1_02_001_htmlcontactform()-passed");
		  Droppable.Initalizedriver("firefox"); Droppable.Tc1_03_001_droppable();
		  Droppable.Tc1_03_002_droppable(); Droppable.Closedriver();
		  System.out.println("Tc1_03_001_droppable()-passed");
		  System.out.println("Tc1_03_002_droppable()-passed");
		  Datepicker.Initalizedriver("firefox"); Datepicker.Tc1_04_001_datepicker();
		  Datepicker.Closedriver();
		  System.out.println("Tc1_04_001_datepicker()-passed");
		  Selectmenu.Initalizedriver("firefox"); Selectmenu.Tc1_05_001_selectmenu();
		  Selectmenu.Tc1_05_002_selectmenu(); Selectmenu.Tc1_05_003_selectmenu();
		  Selectmenu.Tc1_05_004_selectmenu(); Selectmenu.Closedriver();
		  System.out.println("Tc1_05_001_selectmenu()-passed");
		  System.out.println("Tc1_05_002_selectmenu()-passed");
		  System.out.println("Tc1_05_003_selectmenu()-passed");
		  System.out.println("Tc1_05_004_selectmenu()-passed");
		  Carrentalblock.Initalizedriver("firefox");
		  Carrentalblock.Tc1_06_001_carrentalblock();
		  Carrentalblock.Tc1_06_002_carrentalblock(); Carrentalblock.Closedriver();
		  System.out.println("Tc1_06_001_carrentalblock()-passed");
		  System.out.println("Tc1_06_002_carrentalblock()-passed");
		 

		UserRegAndSignIn_UKEnglish.Initalizedriver("firefox");
		UserRegAndSignIn_UKEnglish.Tc2_01_001_RegistrationSignInUK();
		UserRegAndSignIn_UKEnglish.Tc2_01_002_InvalidPasswordValidationUK();
		UserRegAndSignIn_UKEnglish.Tc2_01_003_ForgotPasswordValidationUK();
		UserRegAndSignIn_UKEnglish.Closedriver();
		System.out.println("Tc2_01_001_RegistrationSignInUK()-passed");
		System.out.println("Tc2_01_002_InvalidPasswordValidationUK()-passed");
		System.out.println("Tc2_01_003_ForgotPasswordValidationUK()-passed");

		
		  UserRegAndSignIn_Chinese.Initalizedriver("firefox");
		  UserRegAndSignIn_Chinese.Tc2_02_001_RegistrationSignInCN();
		  UserRegAndSignIn_Chinese.Tc2_02_002_InvalidPasswordValidationCN();
		  UserRegAndSignIn_Chinese.Tc2_02_003_ForgotPasswordValidationCN();
		  UserRegAndSignIn_Chinese.Closedriver();
		  System.out.println("Tc2_02_001_RegistrationSignInCN()-passed");
		  System.out.println("Tc2_02_002_InvalidPasswordValidationCN()-passed");
		  System.out.println("Tc2_02_003_ForgotPasswordValidationCN()-passed");
		  
		  
		  
		  
		  UserRegAndSignIn_Germany.Initalizedriver("firefox");
		  UserRegAndSignIn_Germany.Tc2_03_001_RegistrationSignInDE();
		  UserRegAndSignIn_Germany.Tc2_03_002_InvalidPasswordValidationDE();
		  UserRegAndSignIn_Germany.Tc2_03_003_ForgotPasswordValidationDE();
		  UserRegAndSignIn_Germany.Closedriver();
		  System.out.println("Tc2_03_001_RegistrationSignInDE()-passed");
		  System.out.println("Tc2_03_002_InvalidPasswordValidationDE()-passed");
		  System.out.println("Tc2_03_003_ForgotPasswordValidationDE()-passed");
		  
		  
		  
		  
		  UserRegAndSignIn_Spanish.Initalizedriver("firefox");
		  UserRegAndSignIn_Spanish.Tc2_04_001_RegistrationSignInES();
		  UserRegAndSignIn_Spanish.Tc2_04_002_InvalidPasswordValidationES();
		  UserRegAndSignIn_Spanish.Tc2_04_003_ForgotPasswordValidationES();
		  UserRegAndSignIn_Spanish.Closedriver();
		  System.out.println("Tc2_04_001_RegistrationSignInES()-passed");
		  System.out.println("Tc2_04_002_InvalidPasswordValidationES()-passed");
		  System.out.println("Tc2_04_003_ForgotPasswordValidationES()-passed");
		  
		  
		  MakeMyTripBooking.Initalizedriver("firefox");
		  MakeMyTripBooking.Tc3_01_001_MakeMyTripBooking();
		  MakeMyTripBooking.Closedriver();
		  System.out.println("Tc3_01_001_MakeMyTripBooking()-passed");
		  
		 

	}

}
