package priyankaAssignmentBaseclass;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileReader;
import java.util.Random;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Parameters;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.markuputils.ExtentColor;
import com.aventstack.extentreports.markuputils.MarkupHelper;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;
import com.aventstack.extentreports.reporter.configuration.Theme;
public class Baseclass {
	
	static WebDriver driver;
	static int a;
	static JSONObject user;
	 static File file;
	 static FileInputStream fis;
	 static XSSFWorkbook workbook;
	 static XSSFSheet sh;
	  static ExtentReports reports;
	  static ExtentTest log;
	 static  ExtentHtmlReporter ex;
  
	 
@Parameters({"browser"})
 @BeforeTest
  public static void CreateExtendReports(String browser)
  
	 { 
	   String path;
	   if(browser.equalsIgnoreCase("chrome"))
	   {
	      path=System.getProperty("user.dir")+"./Reports/extentReportChrome.html";
	   }
	   else
	   {
		   path=System.getProperty("user.dir")+"./Reports/extentReportFirefox.html";  
	   }
		 ex=new ExtentHtmlReporter(path);
		 reports=new ExtentReports();
		 reports.attachReporter(ex);
		 reports.setSystemInfo("Host Name", "Selenium");
		 reports.setSystemInfo("User Name", "PRIYANKA S");
		 reports.setSystemInfo("Browser Name", browser);
		 ex.config().setDocumentTitle("Assignments"); 
             
		ex.config().setReportName("Selenium with maven and TestNG"); 
             // Dark Theme
		ex.config().setTheme(Theme.STANDARD);
	 }

	
	  @AfterMethod
	  public static void Testresult(ITestResult result) {
	  if(result.getStatus()==ITestResult.FAILURE) {
       log.fail(MarkupHelper.createLabel(result.getName()+"Test case failed",ExtentColor.RED)); 
	  log.fail(MarkupHelper.createLabel(result.getThrowable().toString(), ExtentColor.RED));
	  } else if(result.getStatus()==ITestResult.SUCCESS) {
	  log.pass(MarkupHelper.createLabel(result.getName()+"Test case passed",
	  ExtentColor.GREEN)); } else {
	  log.skip(MarkupHelper.createLabel(result.getName()+"Test case skipped",
	  ExtentColor.YELLOW)); } 
	  driver.quit(); 
	  reports.flush();
	  }
	 
	 public static ExtentTest Createtest(String methodname)
  {
	 log=reports.createTest(methodname);
	 return log;
  }
	
	 
public static WebDriver Getdriver(String browser) throws Exception {
		
	   
		if(browser.equalsIgnoreCase("Chrome"))
	  {
		  
		  System.setProperty("webdriver.chrome.driver",
		  "C:\\Users\\PR376472\\eclipse-workspace\\priyanka-sdet-selenium\\src\\drivers\\chromedriver.exe");
		  driver= new ChromeDriver(); 
		  }
	  else if(browser.equalsIgnoreCase("Firefox"))
	  {
		  
		  System.setProperty("webdriver.gecko.driver","C:\\Users\\PR376472\\eclipse-workspace\\Testng_framework\\src\\test\\java\\drivers\\geckodriver.exe");
		    
			driver= new FirefoxDriver(); 
		  }
		return driver;
		
		
}
	public static JSONObject readWriteJSON() throws Exception {
		  JSONParser jsonParser = new JSONParser();
		  try  {
		  FileReader reader = new FileReader("C:\\Users\\PR376472\\eclipse-workspace\\Testng_framework\\src\\test\\java\\files\\PriyankaAssigment2Datasheet_Spanish.json");
		  //Read JSON file
		              Object obj = jsonParser.parse(reader);
		              JSONArray usersList = (JSONArray) obj;
			   JSONObject users = (JSONObject) usersList.get(0);
			    user = (JSONObject) users.get("users");
			   
			  System.out.println(user); //This prints each data in the block
			  
			  
			 }
		               catch (Exception e)
		              {
		  e.printStackTrace();
		  }
		  return user;
		  }
	
	public static XSSFSheet Readexcel() throws Exception
     {
 	 
      file= new File("C:\\Users\\PR376472\\eclipse-workspace\\Testng_framework\\src\\test\\java\\files\\priyankaAssignment2Datasheet_German.xlsx");
 	 fis= new FileInputStream(file);
 	  workbook = new XSSFWorkbook (fis);
 	    XSSFSheet sh=workbook.getSheet("assignment2-DE");
 	   return sh;
		 }
      
    
	public static int Random()
	  {
		  Random r=new Random();
		   a=r.nextInt(1000);
		   return a;
	  }
	
	

}
