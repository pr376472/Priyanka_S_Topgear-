package priyankaAssignment3;

import java.io.FileInputStream;
import java.util.List;
import java.util.Properties;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import priyankaAssignmentBaseclass.Baseclass;





public class MakeMyTripBooking extends Baseclass{
	static WebDriver driver;
	 Properties pro;
	 FileInputStream fs;
	 

	 @Parameters({"browser"})
	 @BeforeMethod
		public void Initializedriver(@Optional String browser) throws Exception {
			
	  driver=Getdriver(browser);
	  pro=new Properties(); 
	    fs=new FileInputStream( "C:\\Users\\PR376472\\eclipse-workspace\\Testng_framework\\src\\test\\java\\files\\priyankaAssignment3.properties"); 
	     pro.load(fs);
	
	 }
	 
	
	 @Test
	 public void Tc3_01_001_MakeMyTripBooking() throws Exception{
		 Createtest("Tc3_01_001_MakeMyTripBooking");
		driver.manage().window().maximize();
		driver.get(pro.getProperty("url3"));
		WebElement w=driver.findElement(By.xpath(pro.getProperty("twoway")));
		w.click();
		driver.findElement(By.xpath(pro.getProperty("src"))).click();
	    driver.findElement(By.id(pro.getProperty("srccity"))).click();
		driver.findElement(By.id(pro.getProperty("destcity"))).click();
	    date(pro.getProperty("srcdate"),"20");
	    date(pro.getProperty("destdate"),"30");
	    driver.findElement(By.xpath(pro.getProperty("search"))).click();
	    Thread.sleep(20000);
	    driver.findElement(By.xpath(pro.getProperty("book"))).click();
	    Thread.sleep(10000);
	    driver.findElement(By.cssSelector(pro.getProperty("continue"))).click();
	    //String w1=driver.getWindowHandle();
	    driver.navigate().to(pro.getProperty("newurl"));
	    Thread.sleep(5000);
	    List<WebElement> l=driver.findElements(By.cssSelector(pro.getProperty("getdetails")));
	    for(int i=0;i<l.size();i++)
	    {
	    	System.out.println(l.get(i).getText());
	    	System.out.println("-----------------------");
	    }
	 }
	public void date(String s,String s1)
	{
		List<WebElement> li=driver.findElements(By.xpath(s));
		for(int i=0;i<li.size();i++)
		{
			if(li.get(i).getText().equalsIgnoreCase(s1))
			{
				System.out.println(li.get(i).getText());
				li.get(i).click();
				break;
			}
		}
	}}
	
