package priyankaAssignment1;


import java.io.FileInputStream;
import java.util.List;
import java.util.Properties;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import priyankaAssignmentBaseclass.Baseclass;


public class Carrentalblock extends Baseclass
{
	 static WebDriver driver;
	 Properties pro;
	 FileInputStream fs;
	
	
	 @Parameters({"browser"})
	 @BeforeMethod
		public void Initializedriver(@Optional String browser) throws Exception 
	 {
		
        driver=Getdriver(browser);
	    pro=new Properties(); 
	    fs=new FileInputStream( "C:\\Users\\PR376472\\eclipse-workspace\\Testng_framework\\src\\test\\java\\files\\priyankaAssignment1.properties"); 
	     pro.load(fs);
	    
	 }
	 
	 String s6 = "SUV";
	String txt1 = "";
	
	@Test
	public void Tc1_06_001_carrentalblock() 
	 {
		Createtest("Tc1_06_001_carrentalblock");
		
		 driver.get(pro.getProperty("rentcarurl"));
		 driver.manage().window().maximize();
			driver.findElement(By.id("car-type-button")).click();
			List<WebElement> str1 = driver.findElements(By.xpath(pro.getProperty("cartypemenu1")));

			for (int i = 0; i < str1.size(); i++) {

				txt1 = str1.get(i).getText();
				if (txt1.equalsIgnoreCase(s6)) {
					str1.get(i).click();
					break;
				}
			}
			driver.findElement(By.xpath(pro.getProperty("transmisson1"))).click();
			driver.findElement(By.xpath(pro.getProperty("insurance1"))).click();
			driver.findElement(By.xpath(pro.getProperty("spinner1"))).sendKeys("2");
			driver.findElement(By.xpath(pro.getProperty("button1"))).click();
			
	 }
			
					  
			String s7 = "Luxury"; 
			String txt2 = "";
			
			@Test
			public void Tc1_06_002_carrentalblock() 
			 {
				Createtest("Tc1_06_002_carrentalblock");
				 driver.get(pro.getProperty("rentcarurl"));
				 driver.manage().window().maximize();
					driver.findElement(By.id("ui-id-8-button")).click();
					List<WebElement> str1 = driver.findElements(By.xpath(pro.getProperty("cartypemenu2")));

					for (int i = 0; i < str1.size(); i++) {

						txt2= str1.get(i).getText();
						if (txt2.equalsIgnoreCase(s7)) {
							str1.get(i).click();
							break;
						}
					}
					driver.findElement(By.xpath(pro.getProperty("transmisson2"))).click();
					driver.findElement(By.xpath(pro.getProperty("insurance2"))).click();
					driver.findElement(By.xpath(pro.getProperty("spinner2"))).sendKeys("1");
					driver.findElement(By.xpath(pro.getProperty("button2"))).click();
					
			 }}