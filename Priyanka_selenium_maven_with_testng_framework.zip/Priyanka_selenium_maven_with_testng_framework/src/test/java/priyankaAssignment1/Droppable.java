package priyankaAssignment1;

import java.io.FileInputStream;
import java.util.Properties;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import priyankaAssignmentBaseclass.Baseclass;



public class Droppable extends Baseclass {
	static WebDriver driver;
	 Properties pro;
	 FileInputStream fs;
	
	
	 @Parameters({"browser"})
	 @BeforeMethod
		public void Initializedriver(@Optional String browser) throws Exception {
		 
	  driver=Getdriver(browser);
	  pro=new Properties(); 
	    fs=new FileInputStream( "C:\\Users\\PR376472\\eclipse-workspace\\Testng_framework\\src\\test\\java\\files\\priyankaAssignment1.properties"); 
	     pro.load(fs);
	
	 }
	  
	 @Test
		public void Tc1_01_001_droppable() {
		 Createtest("Tc1_01_001_droppable");
			 driver.get(pro.getProperty("dragurl")); 
		       WebElement src = driver.findElement(By.xpath(pro.getProperty("source")));
				WebElement dest = driver.findElement(By.xpath(pro.getProperty("destination")));
				Actions act = new Actions(driver);
				act.dragAndDrop(src, dest).build().perform();
			WebElement w=driver.findElement(By.xpath("//div[@id='droppable']"));
			if(w.getText().equalsIgnoreCase("dropped!"))
			{
				System.out.println("box is dropped");
			}
				
			}
		 
	 @Test
	 public void Tc1_01_002_droppable() {
		 Createtest("Tc1_01_002_droppable");
			 driver.get(pro.getProperty("dragurl")); 
		       WebElement src = driver.findElement(By.xpath(pro.getProperty("source")));
				WebElement dest = driver.findElement(By.xpath(pro.getProperty("newdest")));
				Actions act = new Actions(driver);
				act.dragAndDrop(src, dest).build().perform();
				
		
		  WebElement w=driver.findElement(By.xpath("//div[@id='droppable']"));
		  if(!w.getText().equalsIgnoreCase("dropped!")) {
		  System.out.println("box is not dropped"); }
		 
			}
	 
		}
	  
	  
	

