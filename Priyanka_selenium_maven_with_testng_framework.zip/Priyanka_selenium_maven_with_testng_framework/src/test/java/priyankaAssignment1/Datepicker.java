package priyankaAssignment1;

import java.io.FileInputStream;
import java.util.List;
import java.util.Properties;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import priyankaAssignmentBaseclass.Baseclass;


public class Datepicker extends Baseclass{
	static WebDriver driver;
	 Properties pro;
	 FileInputStream fs;
	
	
	 @Parameters({"browser"})
	 @BeforeMethod
		public void Initializedriver(@Optional String browser) throws Exception {
		 
	  driver=Getdriver(browser);
	  pro=new Properties(); 
	    fs=new FileInputStream( "C:\\Users\\PR376472\\eclipse-workspace\\Testng_framework\\src\\test\\java\\files\\priyankaAssignment1.properties"); 
	     pro.load(fs);
	
	 }
	 
	 
	 @Test
	public void Tc1_04_001_datepicker() 
		 {
		 Createtest("Tc1_04_001_datepicker");
				driver.get(pro.getProperty("datepickurl"));
				driver.findElement(By.xpath(pro.getProperty("datepicker"))).click();
				for (;;) {
					WebElement wb2 = driver.findElement(By.xpath(pro.getProperty("datepicktriangle")));
					wb2.click();
					WebElement wb1 = driver.findElement(By.xpath(pro.getProperty("datepicktitle")));
					if (wb1.getText().equalsIgnoreCase("March 1995")) {
						break;
					}
				}
				List<WebElement> lt = driver.findElements(By.xpath(pro.getProperty("datepickcalendar")));
				for (int i = 0; i < lt.size(); i++) {
					if (lt.get(i).getText().equalsIgnoreCase("16")) {
						lt.get(i).click();
						break;
					}
				}

			}
}