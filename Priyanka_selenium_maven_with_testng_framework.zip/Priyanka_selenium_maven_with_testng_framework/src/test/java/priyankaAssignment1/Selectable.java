package priyankaAssignment1;

import java.io.FileInputStream;
import java.util.List;
import java.util.Properties;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import priyankaAssignmentBaseclass.Baseclass;


public class Selectable extends Baseclass{
	static WebDriver driver;
	 Properties pro;
	 FileInputStream fs;
	
	
	 @Parameters({"browser"})
	 @BeforeMethod
		public void Initializedriver(@Optional String browser) throws Exception {
		
	  driver=Getdriver(browser);
	  pro=new Properties(); 
	    fs=new FileInputStream( "C:\\Users\\PR376472\\eclipse-workspace\\Testng_framework\\src\\test\\java\\files\\priyankaAssignment1.properties"); 
	     pro.load(fs);
	
	 }
	 
	 
  
	 @Test
	public void Tc1_01_001_selectable() {
		 Createtest("Tc1_01_001_selectable");
		driver.get(pro.getProperty("url")); 
		List<WebElement> wb = driver.findElements(By.xpath(pro.getProperty("clickurl")));

		for (int i = 0; i < wb.size(); i++) {
			wb.get(i).click();
			String txt = wb.get(i).getText();
			System.out.println(txt);
		}
	}
  
  
}
