package priyankaAssignment1;

import java.io.FileInputStream;
import java.util.Properties;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import priyankaAssignmentBaseclass.Baseclass;



public class Htmlcontactform extends Baseclass{
	static WebDriver driver;
	 Properties pro;
	 FileInputStream fs;
	
	
	 @Parameters({"browser"})
	 @BeforeMethod
		public void Initializedriver(@Optional String browser) throws Exception {
		
      driver=Getdriver(browser);
	  pro=new Properties(); 
	    fs=new FileInputStream( "C:\\Users\\PR376472\\eclipse-workspace\\Testng_framework\\src\\test\\java\\files\\priyankaAssignment1.properties"); 
	     pro.load(fs);
	
	 }
	 
	
	
	 @Test
  public void Tc1_02_001_htmlcontactform() {
		 Createtest("Tc1_02_001_htmlcontactform");
		driver.get(pro.getProperty("formurl")); 
		driver.findElement(By.xpath(pro.getProperty("firstname"))).sendKeys("Priyanka");
		driver.findElement(By.xpath(pro.getProperty("lastname"))).sendKeys("s");
		driver.findElement(By.xpath(pro.getProperty("country"))).sendKeys("India");
		driver.findElement(By.xpath(pro.getProperty("description"))).sendKeys("No comments");
		driver.findElement(By.partialLinkText(pro.getProperty("firstlink"))).sendKeys(Keys.chord(Keys.CONTROL, Keys.RETURN));
		driver.findElement(By.partialLinkText(pro.getProperty("secondlink"))).sendKeys(Keys.chord(Keys.CONTROL, Keys.RETURN));
		driver.findElement(By.xpath(pro.getProperty("formbutton"))).submit();
	   
	 }
  }
  
  

