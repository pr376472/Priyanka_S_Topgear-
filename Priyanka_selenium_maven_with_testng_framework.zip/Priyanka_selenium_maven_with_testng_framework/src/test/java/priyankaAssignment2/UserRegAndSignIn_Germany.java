package priyankaAssignment2;


import java.io.FileInputStream;
import java.util.Properties;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import priyankaAssignmentBaseclass.Baseclass;


public class UserRegAndSignIn_Germany extends Baseclass {
	static WebDriver driver;
	 Properties pro;
	 FileInputStream fs;
	 int a;
	  XSSFSheet sh;
	
	
	 @Parameters({"browser"})
	 @BeforeMethod
		public void Initializedriver(@Optional String browser) throws Exception {
			
	  driver=Getdriver(browser);
	  pro=new Properties(); 
	    fs=new FileInputStream( "C:\\Users\\PR376472\\eclipse-workspace\\Testng_framework\\src\\test\\java\\files\\priyankaAssignment2.properties"); 
	     pro.load(fs);
	
	 } 
      
      @Test 
	  public void Tc2_03_001_RegistrationSignInDE() throws Exception
      {
    	  Createtest("Tc2_03_001_RegistrationSignInDE");
	  driver.get(pro.getProperty("urlde")); 
	  driver.manage().window().maximize();
	  sh= Readexcel();
	  a=Random();
	  Thread.sleep(5000);
	  driver.findElement(By.id(pro.getProperty("acceptcookies"))).click();
	  JavascriptExecutor jse = (JavascriptExecutor)driver;
	   jse.executeScript("window.scrollBy(0,750)", "");
	  driver.findElement(By.xpath(pro.getProperty("registerde"))).click();
	  System.out.println(sh.getRow(1).getCell(9).getRawValue());
	  driver.findElement(By.id(pro.getProperty("gender"))).click();
	  driver.findElement(By.id(pro.getProperty("firstnamede"))).sendKeys(sh.getRow(1).getCell(0).getStringCellValue());
	  driver.findElement(By.id(pro.getProperty("lastnamede"))).sendKeys(sh.getRow(1).getCell(1).getStringCellValue());
	  driver.findElement(By.id(pro.getProperty("emailde"))).sendKeys(sh.getRow(1).getCell(2).getStringCellValue()+a+"@gmail.com") ; 
	  driver.findElement(By.id(pro.getProperty("passwordpassde"))).sendKeys(sh.getRow(1).getCell(3).getStringCellValue());
	  driver.findElement(By.id(pro.getProperty("confirmpasswordde"))).sendKeys(sh.getRow(1).getCell(4).getStringCellValue()); 
	  Select s=new Select(driver.findElement(By.id(pro.getProperty("birthdayde"))));
	  s.selectByVisibleText(sh.getRow(1).getCell(5).getRawValue()); 
	  Select s1=new Select(driver.findElement(By.id(pro.getProperty("birthmonthde"))));
	  s1.selectByVisibleText(sh.getRow(1).getCell(6).getRawValue());
	  Select s2=new Select(driver.findElement(By.id(pro.getProperty("birthyearde"))));
	  s2.selectByVisibleText(sh.getRow(1).getCell(7).getRawValue());
	  Select s3=new Select(driver.findElement(By.id(pro.getProperty("landde"))));
	  s3.selectByVisibleText(sh.getRow(1).getCell(8).getStringCellValue());
	  driver.findElement(By.id(pro.getProperty("addresslinede"))).sendKeys(sh.getRow(1).getCell(9).getStringCellValue());
	  driver.findElement(By.id(pro.getProperty("addresspostalde"))).sendKeys(sh.getRow(1).getCell(10).getRawValue());
	  driver.findElement(By.id(pro.getProperty("addresscityde"))).sendKeys(sh.getRow(1).getCell(11).getStringCellValue());
	  JavascriptExecutor jse1 = (JavascriptExecutor)driver;
      jse1.executeScript("window.scrollBy(0,250)", "");
	  driver.findElement(By.id(pro.getProperty("submitde"))).click();
	  Thread.sleep(3000);
	  System.out.println("The system error cannot be solved with any set of values hence validated until this");
	  
	  }
	  
	  String
	  st="Die eingegebene Kombination aus Passwort und E-Mail-Adresse ist ung�ltig. Bitte versuchen Sie es erneut oder klicken Sie auf den Link unten, um ein neues Konto zu erstellen.";
	  
	  
	  @Test
	  public void Tc2_03_002_InvalidPasswordValidationDE() throws Exception {
		  Createtest("Tc2_03_002_InvalidPasswordValidationDE");
	  driver.get(pro.getProperty("urlde")); driver.manage().window().maximize();
	  Thread.sleep(5000); 
	  sh= Readexcel();
	  driver.findElement(By.id(pro.getProperty("acceptcookies"))).click();
	  driver.findElement(By.xpath(pro.getProperty("clicksigninde"))). click();
	  driver.findElement(By.id(pro.getProperty("usernamede"))).sendKeys(sh.getRow(1).getCell(12).getStringCellValue());
	  driver.findElement(By.id(pro.getProperty("passwordde"))).sendKeys(sh.getRow(1).getCell(13).getStringCellValue());
	  driver.findElement(By.id(pro.getProperty("signinbtnde"))).click();
	  Thread.sleep(3000);
	  WebElement w=driver.findElement(By.id(pro.getProperty("messagede")));
	  if(w.getText().equalsIgnoreCase(st)) {
	  System.out.println("Invalid password message is validated"); }
	  
	  
	  }
	  
	  @Test 
	  public void Tc2_03_003_ForgotPasswordValidationDE() throws Exception { 
		  Createtest("Tc2_03_003_ForgotPasswordValidationDE");
		  driver.get(pro.getProperty("urlde"));
	  driver.manage().window().maximize(); 
	  Thread.sleep(5000); 
	  sh= Readexcel();
	  driver.findElement(By.id(pro.getProperty("acceptcookies"))).click();
	  driver.findElement(By.xpath(pro.getProperty("clicksigninde"))). click();
	  driver.findElement(By.id(pro.getProperty("forgotpassclickde"))).click();
	  driver.findElement(By.id(pro.getProperty("usernamede"))).sendKeys(sh.getRow(1).getCell(12).getStringCellValue());
	  driver.findElement(By.id(pro.getProperty("nextbuttonde"))).click(); 
	  System.out.println("Any of the values are not able to register hence this cannot be validated");
	  }
	 
}
