package priyankaAssignment2;

import java.io.FileInputStream;
import java.util.Properties;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import priyankaAssignmentBaseclass.Baseclass;

public class UserRegAndSignIn_Chinese extends Baseclass{

	static WebDriver driver;
	 Properties pro;
	 FileInputStream fs;
	 int a;
	
	
	 @Parameters({"browser"})
	 @BeforeMethod
		public void Initializedriver(@Optional String browser) throws Exception {
			
	  driver=Getdriver(browser);
	  pro=new Properties(); 
	    fs=new FileInputStream( "C:\\Users\\PR376472\\eclipse-workspace\\Testng_framework\\src\\test\\java\\files\\priyankaAssignment2.properties"); 
	     pro.load(fs);
	
	 }
	 
	@Test
	public void Tc2_02_001_RegistrationSignInCN() throws Exception {
		Createtest("Tc2_02_001_RegistrationSignInCN");
		driver.get(pro.getProperty("urlcn"));
		a=Random();
		driver.manage().window().maximize();
		Thread.sleep(5000);
		driver.findElement(By.xpath(pro.getProperty("registercn"))).click();
		Thread.sleep(5000);
		driver.findElement(By.xpath(pro.getProperty("lastnamecn"))).sendKeys("s");
		driver.findElement(By.id(pro.getProperty("firstnamecn"))).sendKeys("priyanka");
	    driver.findElement(By.id(pro.getProperty("emailcn"))).sendKeys("priya"+a+"@gmail.com");
	    driver.findElement(By.id(pro.getProperty("phonenumcn"))).sendKeys("+852349"+a+"99");
		driver.findElement(By.id(pro.getProperty("passwordpasscn"))).sendKeys("priya@123");
		driver.findElement(By.id(pro.getProperty("confirmpasswordcn"))).sendKeys("priya@123");
		 driver.findElement(By.id(pro.getProperty("addresscn"))).sendKeys("Blue valley");
		Select s1 = new Select(driver.findElement(By.id(pro.getProperty("birthmonthcn"))));
		s1.selectByValue("03");
		Select s2 = new Select(driver.findElement(By.id(pro.getProperty("birthyearcn"))));
		s2.selectByVisibleText("1995");
		driver.findElement(By.id(pro.getProperty("checkboxcn"))).click();
		driver.findElement(By.id(pro.getProperty("submitcn"))).click();
		Thread.sleep(3000);
		driver.findElement(By.id(pro.getProperty("usernamecn"))).sendKeys("priya"+a+"@gmail.com");
		driver.findElement(By.id(pro.getProperty("passwordcn"))).sendKeys("priya@123");
		driver.findElement(By.xpath(pro.getProperty("signinbtncn"))).click();
		
	}

	String st ="您輸入的電郵或密碼不正確。請再試一次，或點擊下方連結新建一個帳戶";

	
	@Test
	public void Tc2_02_002_InvalidPasswordValidationCN() throws Exception {
		Createtest("Tc2_02_002_InvalidPasswordValidationCN");
		driver.get(pro.getProperty("urlcn"));
		driver.manage().window().maximize();
		Thread.sleep(10000);
		driver.findElement(By.cssSelector(pro.getProperty("clicksignincn"))).click();
		driver.findElement(By.id(pro.getProperty("usernamecn"))).sendKeys("privasan@gmail.com");
		driver.findElement(By.id(pro.getProperty("passwordcn"))).sendKeys("priya@345");
		driver.findElement(By.xpath(pro.getProperty("signinbtncn"))).click();
		Thread.sleep(3000);
		WebElement w = driver.findElement(By.id(pro.getProperty("messagecn")));
		if (w.getText().equalsIgnoreCase(st)) {
			System.out.println("Invalid password message is validated");
		}
	
	}
	
	String s="我們已發出一封電子郵件到你的電郵信箱，請點擊郵件內的連結以重設密碼";

	@Test
	public void Tc2_02_003_ForgotPasswordValidationCN() throws Exception {
		Createtest("Tc2_02_003_ForgotPasswordValidationCN");
		driver.get(pro.getProperty("urlcn"));
		driver.manage().window().maximize();
		Thread.sleep(10000);
		driver.findElement(By.cssSelector(pro.getProperty("clicksignincn"))).click();
		Thread.sleep(3000);
		driver.findElement(By.id(pro.getProperty("forgotpassclickcn"))).click();
		Thread.sleep(3000);
		driver.findElement(By.id(pro.getProperty("usernamecn"))).sendKeys("priya5@gmail.com");
		driver.findElement(By.xpath(pro.getProperty("nextbuttoncn"))).click();
		Thread.sleep(3000);
		WebElement wb = driver.findElement(By.id(pro.getProperty("aftersubmitcn")));
		if(wb.getText().equalsIgnoreCase(s))
		{
			System.out.println("Forgot password is validated");
		}
		
	}

}
