package priyankaAssignment2;
import java.io.FileInputStream;
import java.util.Properties;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import priyankaAssignmentBaseclass.Baseclass;




public class UserRegAndSignIn_UKEnglish extends Baseclass {
	
	 static WebDriver driver;
	 Properties pro;
	 FileInputStream fs;
	 int a;
	  
	 @Parameters({"browser"})
	 @BeforeMethod
		public void Initializedriver(@Optional String browser) throws Exception {
			
	  driver=Getdriver(browser);
	  pro=new Properties(); 
	    fs=new FileInputStream( "C:\\Users\\PR376472\\eclipse-workspace\\Testng_framework\\src\\test\\java\\files\\priyankaAssignment2.properties"); 
	     pro.load(fs);
	
	 }
	
	 
	   @Test 
	  public void Tc2_01_001_RegistrationSignInUK() throws Exception
      {
		   Createtest("Tc2_01_002_InvalidPasswordValidationUK");
	  driver.get(pro.getProperty("urlen")); 
	  driver.manage().window().maximize();
	  Thread.sleep(5000);
	   int a=Random();
	  driver.findElement(By.id(pro.getProperty("rejectcookies"))).click();
	  driver.findElement(By.linkText(pro.getProperty("register"))).click();
	  driver.findElement(By.id(pro.getProperty("email"))).sendKeys(pro.getProperty("username")+a+"@gmail.com") ; 
	  driver.findElement(By.id(pro.getProperty("passwordpass"))).sendKeys("priya@123");
	  driver.findElement(By.id(pro.getProperty("confirmpassword"))).sendKeys("priya@123"); 
	  Select s=new Select(driver.findElement(By.id(pro.getProperty("birthday"))));
	  s.selectByVisibleText("16"); 
	  Select s1=new Select(driver.findElement(By.id(pro.getProperty("birthmonth"))));
	  s1.selectByVisibleText("3");
	  Select s2=new Select(driver.findElement(By.id(pro.getProperty("birthyear"))));
	  s2.selectByVisibleText("1995"); JavascriptExecutor jse = (JavascriptExecutor)
	  driver; jse.executeScript("window.scrollBy(0,250)", "");
	  driver.findElement(By.id(pro.getProperty("submit"))).click();
	  driver.findElement(By.id(pro.getProperty("firstname"))).sendKeys("priya");
	  driver.findElement(By.id(pro.getProperty("lastname"))).sendKeys("s");
	  driver.findElement(By.id(pro.getProperty("addressline"))).sendKeys("123");
	  driver.findElement(By.id(pro.getProperty("addresscity"))).sendKeys("chennai");
	  driver.findElement(By.id(pro.getProperty("addresspostal"))).sendKeys("145214"); 
	  driver.findElement(By.id(pro.getProperty("submitbtn"))).click();
	  driver.findElement(By.id(pro.getProperty("username"))).sendKeys(pro.getProperty("username")+a+"@gmail.com");
	  driver.findElement(By.id(pro.getProperty("password"))).sendKeys("priya@123");
	  driver.findElement(By.id(pro.getProperty("signinbtn"))).click();
	  }
	  
	  String
	  st="The email and password combination you entered is incorrect. Please try again, or click the link below to create an account.";
	  
	  
	  @Test
	  public void Tc2_01_002_InvalidPasswordValidationUK() throws Exception {
		  Createtest("Tc2_01_002_InvalidPasswordValidationUK");
	  driver.get(pro.getProperty("urlen")); driver.manage().window().maximize();
	  Thread.sleep(5000); 
	  int a=Random();
	  driver.findElement(By.id(pro.getProperty("rejectcookies"))).click();
	  driver.findElement(By.xpath(pro.getProperty("clicksignin"))). click();
	  driver.findElement(By.id(pro.getProperty("username"))).sendKeys( pro.getProperty("username")+a+"@gmail.com");
	  driver.findElement(By.id(pro.getProperty("password"))).sendKeys("priya@123");
	  driver.findElement(By.id(pro.getProperty("signinbtn"))).click();
	  Thread.sleep(3000); WebElement
	  w=driver.findElement(By.id(pro.getProperty("message")));
	  if(w.getText().equalsIgnoreCase(st)) {
	  System.out.println("Invalid password message is validated"); }
	  
	  
	  }
	  
	  @Test 
	  public void Tc2_01_003_ForgotPasswordValidationUK() throws
	  InterruptedException { 
		  Createtest("Tc2_01_003_ForgotPasswordValidationUK");
		  driver.get(pro.getProperty("urlen"));
	  driver.manage().window().maximize(); Thread.sleep(5000); //
	  driver.findElement(By.id(pro.getProperty("rejectcookies"))).click();
	  driver.findElement(By.xpath(pro.getProperty("clicksignin"))). click();
	  driver.findElement(By.id(pro.getProperty("forgotpassclick"))).click();
	  driver.findElement(By.id(pro.getProperty("username"))).sendKeys(
	  "privasan95@gmail.com");
	  driver.findElement(By.id(pro.getProperty("nextbutton"))).click(); WebElement
	  wb= driver.findElement(By.id(pro.getProperty("aftersubmit")));
	  System.out.println(wb.getText()); }
	 
}
